package net.minecraft.item;

public class ItemSimpleFoiled extends Item {
   public boolean hasEffect(ItemStack stack) {
      return true;
   }
}
