package net.minecraft.inventory;

public interface IInvBasic {
   void onInventoryChanged(InventoryBasic p_76316_1_);
}
