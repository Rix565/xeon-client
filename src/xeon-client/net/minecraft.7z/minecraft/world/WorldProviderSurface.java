package net.minecraft.world;

public class WorldProviderSurface extends WorldProvider {
   public String getDimensionName() {
      return "Overworld";
   }

   public String getInternalNameSuffix() {
      return "";
   }
}
