package net.minecraft.world.biome;

public class BiomeGenRiver extends BiomeGenBase {
   public BiomeGenRiver(int p_i1987_1_) {
      super(p_i1987_1_);
      this.spawnableCreatureList.clear();
   }
}
