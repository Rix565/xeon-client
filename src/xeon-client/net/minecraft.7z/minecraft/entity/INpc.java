package net.minecraft.entity;

import net.minecraft.entity.passive.IAnimals;

public interface INpc extends IAnimals {
}
