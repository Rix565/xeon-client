package net.minecraft.entity;

public interface IProjectile {
   void setThrowableHeading(double x, double y, double z, float velocity, float inaccuracy);
}
