package net.minecraft.entity;

public interface IRangedAttackMob {
   void attackEntityWithRangedAttack(EntityLivingBase p_82196_1_, float p_82196_2_);
}
