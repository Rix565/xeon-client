package net.minecraft.network;

public enum EnumPacketDirection {
   SERVERBOUND,
   CLIENTBOUND;
}
